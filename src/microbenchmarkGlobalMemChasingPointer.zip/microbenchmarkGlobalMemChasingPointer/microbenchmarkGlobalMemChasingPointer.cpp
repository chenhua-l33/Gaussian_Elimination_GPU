#include <exception>
#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <vector>

#define __CL_ENABLE_EXCEPTIONS
#include <CL/cl.hpp> // CL namespace
#include <JC/util.h>
#include <JC/openCLUtil.hpp>  // JC namespace

using namespace std;
bool PRESS_KEY_TO_CLOSE_WINDOW = false; // when running from within visual studio

int main(int argc, char *argv[])
{
	if (argsContainsOption('h', argc, argv) || argsContainsUnknownOption("bdfhipw", argc, argv)) {
		cout << "Usage: " << argv[0] << " -p <platform ID> -d <device ID> -w <#work items> -i <kernel iterations> -b <barrier> -f <flag>" << endl;
		return 0;
	}

	if (argc > 1)
		PRESS_KEY_TO_CLOSE_WINDOW = false; // running from terminal

	try {
		// *0* Configuration
		string kernel_file("microbenchmarkKernels.ocl");
		string kernel_name("globalMemoryReadsChasingPointer");

		int PLATFORM_ID = defaultOrViaArgs(0, 'p', argc, argv);
		int DEVICE_ID = defaultOrViaArgs(0, 'd', argc, argv);
		uint WORK_ITEMS = defaultOrViaArgs(1024 * 7 * 9 * 4 * 5, 'w', argc, argv); 
		int NBR_KERNEL_ITERATIONS = defaultOrViaArgs(32, 'i', argc, argv);
		bool barrier = (bool) defaultOrViaArgs(0, 'b', argc, argv);
		int flag = defaultOrViaArgs(0, 'f', argc, argv);

		int ARRAY_SIZE = WORK_ITEMS * NBR_KERNEL_ITERATIONS;

		// *1* OpenCL initialization
		cl::Device device = jc::getDevice(PLATFORM_ID, DEVICE_ID, PRESS_KEY_TO_CLOSE_WINDOW);
		cl::Context context(device);
		cl::CommandQueue queue(context, device, CL_QUEUE_PROFILING_ENABLE);

		string compilerOptions = " -DNBR_KERNEL_ITERATIONS=" + std::to_string(NBR_KERNEL_ITERATIONS)+(barrier?" -DBARRIER":"");

		cl::Program program = jc::buildProgram(kernel_file, context, device, compilerOptions.c_str());
		
		unsigned int clockFrequency = jc::clockFrequency(device); // in MHz
		unsigned int nbrComputeUnits = jc::nbrComputeUnits(device);
		unsigned int warpSize = jc::warpSize(device);

		if (WORK_ITEMS % (nbrComputeUnits * warpSize) != 0) {
			cout << "WARNING: better take nbr work items ("<< WORK_ITEMS  <<") a multiple of #cores ("<< nbrComputeUnits  <<") x warp size ("<< warpSize  <<")!!!" << endl;
		}

		// *2* Allocate memory on the host and populate source
		int* arr = new int[ARRAY_SIZE];
			
		for (int i = 0; i < ARRAY_SIZE; i++) {
			arr[i] = (i + WORK_ITEMS) % ARRAY_SIZE; // stride
		}

		if (flag) cout << "INPUT: " << arr[0] << ", " << arr[1] << ", " << arr[2] << ", " << endl;

		// *3* Allocate memory on the device
		cl::Buffer gpu_buffer(context, CL_MEM_WRITE_ONLY, ARRAY_SIZE * sizeof(cl_int));
		queue.enqueueWriteBuffer(gpu_buffer, CL_TRUE, 0, ARRAY_SIZE * sizeof(cl_int), arr);

		// *4* Create the kernel
		const float NUM_INT = 1; // , CORRECT_RESULT = NUM_INT * NBR_KERNEL_ITERATIONS;


		cl::Kernel kernel(program, kernel_name.c_str());
		kernel.setArg<cl::Buffer>(1, gpu_buffer);
		kernel.setArg<cl_int>(2, NUM_INT);
		kernel.setArg<cl_int>(3, flag);
		
		
		cout << "Executing microbenchmarkGlobalMemory in function of occupancy on device '" << jc::deviceName(device) << "' "<<(barrier? "with barrier":"without barrier")<<", #work items = " << WORK_ITEMS << ", with array size = " << ARRAY_SIZE << " and kernel iterations = " << NBR_KERNEL_ITERATIONS << endl;

		jc::OccupancyIterator occIterator(device, ARRAY_SIZE);

		// output
		cout << " #Conc warps |   #Conc WGs  |     WG size  |   local mem  | #mem instr   | runtime (us) |     MB/s     |  CPWMemI (c) | CPMemIt (c) " << endl;
		const char SEPARATOR = ' ';
		const int NUM_WIDTH = 12, PRECISION = 4;

		while(occIterator.hasNext()){
			int nbrConcWarps = occIterator.next();
		
		//	cout << " ** Occupancy = " << nbrConcWarps << " conc warps => "<< occIterator.getNbrConcWorkgroups() << " conc work groups, work group size = " << occIterator.getWorkGroupSize()<<", local mem="<< occIterator.getLocalMemSizeOfWG()<<"B." <<endl;
			
			kernel.setArg<cl::LocalSpaceArg>(0, cl::__local(occIterator.getLocalMemSizeOfWG())); // *** set local memory ***

			// *5* execute the code on the device
			cl::NDRange global(WORK_ITEMS), local(occIterator.getWorkGroupSize()); // *** set work group size ***
			cl_ulong gpu_time = jc::runAndTimeKernel(kernel, queue, global, local); // time in nanoseconds

			// transfer destination data from the device to the host
			queue.enqueueReadBuffer(gpu_buffer, CL_TRUE, 0, ARRAY_SIZE * sizeof(cl_int), arr);
			if (flag) cout << "GPU result: " << arr[0] << ", " << arr[1] << ", " << arr[2] << ", " << endl;
			
			cl_ulong nbr_cycles = gpu_time * clockFrequency / 1000;
			int nbrMemInstructions = ARRAY_SIZE;
		
			float throughput = (float)nbrMemInstructions * 1000 * sizeof(float) / gpu_time; // MB/s (t is in nano seconds)

			float CPWMemI = (float)nbr_cycles / nbrMemInstructions * nbrComputeUnits * warpSize;
			int totalNbrWarps = WORK_ITEMS / warpSize;
			int warpsPerCore = (int) ceilf((float)totalNbrWarps / nbrComputeUnits);
			double cyclesPerMemIteration = (double)nbr_cycles / ((double)warpsPerCore / nbrConcWarps) / NBR_KERNEL_ITERATIONS;


			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << nbrConcWarps << " | ";
			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << occIterator.getNbrConcWorkgroups() << " | ";
			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << occIterator.getWorkGroupSize() << " | ";
			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << occIterator.getLocalMemSizeOfWG() << " | ";
			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << nbrMemInstructions << " | ";
			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << (int) (gpu_time/1000) << " | ";
			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << (int) throughput << " | ";
			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << setprecision(PRECISION) << CPWMemI << " | ";
			cout << right << setw(NUM_WIDTH) << setfill(SEPARATOR) << setprecision(PRECISION) << cyclesPerMemIteration << " | ";
			cout << endl;
		}

		// Deallocate memory
		delete[] arr;

		if (PRESS_KEY_TO_CLOSE_WINDOW) { cout << endl << "Press ENTER to close window..."; char c = cin.get(); }
		return 0;
	}
	catch (cl::Error& e) {
		cerr << e.what() << ": " << jc::readableStatus(e.err());
		if (PRESS_KEY_TO_CLOSE_WINDOW) { cout << endl << "Press ENTER to close window..."; char c = cin.get(); }
		return 3;
	}
	catch (exception& e) {
		cerr << e.what() << endl;
		if (PRESS_KEY_TO_CLOSE_WINDOW) { cout << endl << "Press ENTER to close window..."; char c = cin.get(); }
		return 2;
	}
	catch (...) {
		cerr << "Unexpected error. Aborting!\n" << endl;
		if (PRESS_KEY_TO_CLOSE_WINDOW) { cout << endl << "Press ENTER to close window..."; char c = cin.get(); }
		return 1;
	}
}